# -*- coding: utf-8 -*-
# © 2014 Nemry Jonathan (Acsone SA/NV) (http://www.acsone.eu)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import (
    test_create,
    test_defaults,
    test_delete,
    test_empty,
    test_name,
    test_onchange,
    test_user_onchange,
    test_order,
)
