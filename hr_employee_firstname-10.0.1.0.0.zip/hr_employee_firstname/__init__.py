# -*- coding: utf-8 -*-
# Copyright (C)  2010 - 2014 Savoir-faire Linux (<http://www.savoirfairelinux.com>)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import models
from .init_hook import post_init_hook
